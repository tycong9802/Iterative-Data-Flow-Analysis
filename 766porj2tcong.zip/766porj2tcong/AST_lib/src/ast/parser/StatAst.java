package ast.parser;

import tools.*;

// The root class of executable statements.
//
abstract public class StatAst extends AstNode {
    StatAst(String nn) {super(nn);}
}