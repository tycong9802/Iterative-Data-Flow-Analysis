package ast.scanner;
public class Meta extends StringToken {
    public Meta(String _str) { super(_str); }
}
