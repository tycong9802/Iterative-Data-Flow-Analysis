package ast.scanner;
import java.io.*;

public class NumToken extends StringToken {
  public NumToken(String _num) {super(_num);}
}
