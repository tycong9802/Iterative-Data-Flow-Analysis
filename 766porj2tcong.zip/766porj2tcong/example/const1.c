
int main() {
  int A[20], i=2;
  A[1+4+5] = 2+i+4;
  printf("%d\n", A[2+8]+2);
}
