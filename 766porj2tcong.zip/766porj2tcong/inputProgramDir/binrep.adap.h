(FileAst "binrep.adap.h" Begin)
(FileAst "binrep.adap.h" End)
