(FileAst "movingedge.adap.h" Begin)
(FileAst "movingedge.adap.h" End)
