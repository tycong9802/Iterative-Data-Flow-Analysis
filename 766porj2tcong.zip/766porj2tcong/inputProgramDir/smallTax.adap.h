(FileAst "smallTax.adap.h" Begin)
(FileAst "smallTax.adap.h" End)
