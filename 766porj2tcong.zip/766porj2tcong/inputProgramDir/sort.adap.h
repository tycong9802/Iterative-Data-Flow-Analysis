(FileAst "sort.adap.h" Begin)
(FileAst "sort.adap.h" End)
