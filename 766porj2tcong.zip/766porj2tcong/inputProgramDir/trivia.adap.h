(FileAst "trivia.adap.h" Begin)
(FileAst "trivia.adap.h" End)
